#ifndef FILE_H
#define FILE_H
#include<QString>
#include <QPainter>
#include<QVector>
#include"quadtree.h"
#include"outrectangle.h"

struct tempNode
{
    int nodeID;
    int parentID;
    float minX,minY,maxX,maxY;
    QVector<RectangleRange*> outRect_list;
    tempNode(int nodeID,int parentID,float minX,float minY,float maxX,float maxY,QVector<int> index_list)
    {
        this->nodeID=nodeID;
        this->parentID=parentID;
        this->minX=minX;
        this->minY=minY;
        this->maxX=maxX;
        this->maxY=maxY;
        index_list=index_list;
    }
};

class File
{
public:
    File();
//    ~File();

    QList<QPoint> getNearbyPoints(int x,int y,int nums);
    QList<QPoint> getRegionPoints(int minX,int minY,int maxX,int maxY);
    QList<int> getAllRange();
    bool readTxtAsData(QString TXTpath,QString DataPath);
    bool readData(QString DataPath);

public:
    QList<QPoint> PointsList;//以点的形式存的整个线
private:
    void ReadInit(QString path,int perLinePointsCount);
    bool makeFileHead(QString path);
    bool makeFileIndex(QString path);
    bool makeFileOutRect(QString path);
    bool readFileHead(QString path);
    bool readFileIndex(QString path);
    bool readFileOutRect(QString path);
    void reset();

private:
    QVector<QVector<QPoint>> LineList;//第一次打开文件构建该数组
    int perLinePointsCount;
    QuadTree<RectangleRange>* quadTree;
    outRectangle* outrectangle_ptr;


};

#endif // FILE_H
