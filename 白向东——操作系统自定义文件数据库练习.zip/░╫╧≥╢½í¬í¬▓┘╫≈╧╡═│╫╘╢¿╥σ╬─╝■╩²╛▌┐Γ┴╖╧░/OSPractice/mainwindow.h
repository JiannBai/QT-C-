#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"file.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *);
private slots:
    void on_actionopen_triggered();

    void on_PointInquire_triggered();

    void on_RegionInquire_triggered();

    void on_PointConfirm_clicked();

    void on_RegionConfirm_clicked();

private:
    File *FClass;
    Ui::MainWindow *ui;
    QList<QPointF> PointsList;
    void standardPointsToShow();
    QList<QPointF> StandarSelectdPointsToShow(QList<QPoint> PointsList);
    QList<QPointF> selectPoints;
    //开关、标记
    bool exist_file;
    bool exist_select_points;

};
#endif // MAINWINDOW_H
