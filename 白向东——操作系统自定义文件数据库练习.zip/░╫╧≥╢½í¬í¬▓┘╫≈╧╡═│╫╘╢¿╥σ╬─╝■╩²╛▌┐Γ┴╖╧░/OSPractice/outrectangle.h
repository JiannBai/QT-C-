#ifndef OUTRECTANGLE_H
#define OUTRECTANGLE_H
#include<QVector>
#include<QPainter>
struct RectangleRange
{
    float minX,minY,maxX,maxY;
    int id;
    RectangleRange(float minX,float minY,float maxX,float maxY,int id)
    {
        this->minX=minX;
        this->minY=minY;
        this->maxX=maxX;
        this->maxY=maxY;
        this->id=id;
    }
    RectangleRange()
    {
        this->minX=0.0;
        this->minY=0.0;
        this->maxX=0.0;
        this->maxY=0.0;
        id=-1;
    }

};

class outRectangle
{
public:
    outRectangle(QVector<QVector<QPoint>> &LineList);
    outRectangle(QVector<QVector<float>> &outRectRangeList);
private:
    void CalRectangle(QVector<QVector<QPoint>> &LineList);
public:
    QVector<RectangleRange*> RectRangeList;
};

#endif // OUTRECTANGLE_H
