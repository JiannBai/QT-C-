#include "outrectangle.h"


outRectangle::outRectangle(QVector<QVector<QPoint>> &LineList)
{
    CalRectangle(LineList);
}

outRectangle::outRectangle(QVector<QVector<float>> &outRectRangeList)
{
    int length=outRectRangeList.length();
    for(int i=0;i<length;++i)
    {
        RectangleRange* perLineRange=new RectangleRange(outRectRangeList[i][0],outRectRangeList[i][1],
                outRectRangeList[i][2],outRectRangeList[i][3],i);
        this->RectRangeList.append(perLineRange);
    }
}

 void outRectangle::CalRectangle(QVector<QVector<QPoint>> &LineList)
{

    int length=LineList.length();
    for(int i=0;i<length;++i)
    {
        float minX=9999999999999999.9;
        float minY=9999999999999999.9;
        float maxX=-9999999999999999.9;
        float maxY=-9999999999999999.9;
        for(auto point:LineList[i])
        {
            if(point.x()<=minX) minX=point.x();
            if(point.x()>=maxX) maxX=point.x();
            if(point.y()<=minY) minY=point.y();
            if(point.y()>=maxY) maxY=point.y();
        }

        RectangleRange* perLineRange=new RectangleRange(minX,minY,maxX,maxY,i);
        this->RectRangeList.append(perLineRange);
    }
}
