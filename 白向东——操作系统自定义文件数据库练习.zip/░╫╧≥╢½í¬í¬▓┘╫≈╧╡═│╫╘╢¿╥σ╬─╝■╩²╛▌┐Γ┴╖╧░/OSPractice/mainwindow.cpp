#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow),exist_file(false),exist_select_points(false)
{
    ui->setupUi(this);
    FClass=new File();



}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)
{
     if(exist_file)
     {
         QPainter painter(this);//绑定控件
         QPen pen;//画笔
         pen.setColor(qRgba(20,30,50,250));//设置画笔颜色
         pen.setWidth(2);
         QBrush brush(Qt::blue);//新建画刷并设置颜色
         painter.setPen(pen);//添加画笔
         painter.setBrush(brush);//添加画刷
         painter.drawPoints(this->PointsList);
     }
     if(exist_select_points)
     {
         QPainter painter(this);//绑定控件
         QPen pen;//画笔
         pen.setColor(qRgba(250,30,40,250));//设置画笔颜色
         pen.setWidth(5);
         painter.setPen(pen);//添加画笔
         painter.drawPoints(this->selectPoints);
     }


}
void MainWindow::standardPointsToShow()
{
    QList<int> range=this->FClass->getAllRange();
    int delta_x=range[2]-range[0];
    int delta_y=range[3]-range[1];
    int count=0;
    for(auto point:this->FClass->PointsList)
    {
        ++count;
        if(count==10)
        {
            this->PointsList.append(QPoint((point.x()-range[0]+20)*600/delta_x+300,(range[3]-point.y()+20)*500/delta_y+100));
            count=0;
        }

    }
}
QList<QPointF> MainWindow::StandarSelectdPointsToShow(QList<QPoint> SelectPointsList)
{
    QList<QPointF> result_points;
    QList<int> range=this->FClass->getAllRange();
    int delta_x=range[2]-range[0];
    int delta_y=range[3]-range[1];
    for(auto point:SelectPointsList)
    {
        result_points.append(QPoint((point.x()-range[0]+20)*600/delta_x+300,(range[3]-point.y()+20)*500/delta_y+100));
    }
    return result_points;
}


void MainWindow::on_actionopen_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(
            this,
            tr("open a file."),
            "../",
            tr("files(*.txt *data *index *or)"));
    QStringList nameAttri=fileName.split('.');

    if(nameAttri[1]=="txt")
    {
        QString newFileName= QFileDialog::getExistingDirectory(this,"选择格式转换后的文件的存储文件夹","../");
        QStringList path=nameAttri[0].split('/');
        int pathAttriLength=path.length();
        this->FClass->readTxtAsData(fileName,newFileName+'/'+path[pathAttriLength-1]);
        this->exist_file=true;
        standardPointsToShow();//显示标准化点坐标

    }
    else if(nameAttri[1]=="data" || nameAttri[1]=="index" || nameAttri[1]=="or")
    {
        this->FClass->readData(nameAttri[0]);
        this->exist_file=true;
        standardPointsToShow();//显示标准化点坐标
    }

}


////点查询
//void MainWindow::on_PointInquire_triggered()
//{

//}

////区域查询
//void MainWindow::on_RegionInquire_triggered()
//{

//}


void MainWindow::on_PointConfirm_clicked()
{

    ui->InquireResult->clear();
    int x=ui->InquirePointX->text().toInt();
    int y=ui->InquirePointY->text().toInt();
    int nums=ui->InquirePointNearNum->text().toInt();
    QList<QPoint> pointList=this->FClass->getNearbyPoints(x,y,nums);

    int length=pointList.length();
    if(length>0)
    {
        QList<QPointF>().swap(this->selectPoints);
        for(int i=0;i<length;++i)
        {
            QString x=QString::number(pointList[i].x(),10);
            QString y=QString::number(pointList[i].y(),10);
            ui->InquireResult->append("P"+QString::number(i,10)+":"+x+"\n"+y+'\n');

        }
        this->selectPoints=this->StandarSelectdPointsToShow(pointList);
        this->exist_select_points=true;
    }
    else
    {
        ui->InquireResult->append("无该点信息！");
    }

}


void MainWindow::on_RegionConfirm_clicked()
{
    ui->InquireResult->clear();
    int x0=ui->InquireRegionX0->text().toInt();
    int y0=ui->InquireRegionY0->text().toInt();
    int x1=ui->InquireRegionX1->text().toInt();
    int y1=ui->InquireRegionY1->text().toInt();
    QList<QPoint> pointList=this->FClass->getRegionPoints(x0,y0,x1,y1);

    int length=pointList.length();
    if(length>0)
    {
        QList<QPointF>().swap(this->selectPoints);
        for(int i=0;i<length;++i)
        {
            QString x=QString::number(pointList[i].x(),10);
            QString y=QString::number(pointList[i].y(),10);
            ui->InquireResult->append("P"+QString::number(i,10)+":"+x+"\n"+y+'\n');

        }
           this->selectPoints=this->StandarSelectdPointsToShow(pointList);
        this->exist_select_points=true;
    }
    else
    {
        ui->InquireResult->append("该索引区域无点！");
    }
}

