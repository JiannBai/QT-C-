#include "file.h"
#include<QFile>
#include<iostream>
#include<QDebug>
#include<QMap>
#include<QMessageBox>

File::File():quadTree(nullptr),outrectangle_ptr(nullptr)
{

}


void File::ReadInit(QString path,int perLinePointsCount)
{
    this->perLinePointsCount=perLinePointsCount;
    QFile f(path);
    if (!f.exists())
    {
        qDebug("改文件不存在!\n");
    }

    f.open(QIODevice::ReadOnly);

    if(f.isOpen())
    {
        QString Point;
        QStringList point_x_y;
        int point_x;
        int point_y;
        int count=0;
        QVector<QPoint> temp;
        while(!f.atEnd())
        {

            Point=QString(f.readLine());       
            point_x_y=Point.split('\t');
            point_x=point_x_y[0].toInt();
            point_y=point_x_y[1].split('\r')[0].toInt();
            //qDebug()<<point_x<<'\t'<<point_y<<'\n';
            PointsList.append(QPoint(point_x,point_y));

            // 分割成较短的线段
            temp.append(QPoint(point_x,point_y));
            ++count;
            if(count>=perLinePointsCount)
            {
                this->LineList.append(temp);
                temp.clear();
                count=0;
            }
        }
        //将最后零头单独列为一个小线段
        if(count!=0) this->LineList.append(temp);
        // 创建 外包矩形类
        this->outrectangle_ptr=new outRectangle(this->LineList);
        //构建四叉树
        this->quadTree=new QuadTree<RectangleRange>(this->outrectangle_ptr->RectRangeList);
    }
    else
    {
        qDebug("文件打开失败！\n");
    }
    f.close();
}

bool File::makeFileHead(QString path)
{
    float minX=9999999999999999.9;
    float minY=9999999999999999.9;
    float maxX=-9999999999999999.9;
    float maxY=-9999999999999999.9;
    for(auto line:this->LineList)
    {
        for(auto point:line)
        {
            if(point.x()<minX) minX=point.x();
            if(point.x()>maxX) maxX=point.x();
            if(point.y()<minY) minY=point.y();
            if(point.y()>maxY) maxY=point.y();
        }
    }

    QString fileName = path+".data";
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
        //错误处理
        return false;
    //流读取文件
    QDataStream stream(&file);
    //windows平台
    stream.setByteOrder(QDataStream::LittleEndian);

    //文件头
    stream<<'3'<<minX<<minY<<maxX<<maxY<<'i'<<qint32(perLinePointsCount);
    //3：00000011代表多线;范围;i:int;每个线的点数 目前使用22字节
//    for(int i=0;i<28;++i)
//    {
//        stream<<NULL;
//    }// 文件头占用50字节

    //文件数据区
    int length=this->LineList.length();
    for(int i=0;i<length;++i)
    {
//        stream<<qint16(this->LineList[i].length()*2);
        for(auto point:this->LineList[i])
        {
            stream<<point.x()<<point.y();
        }
    }
    //关闭文件
    file.close();
    return true;
}

bool File::makeFileIndex(QString path)
{

    QString fileName = path+".index";
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate|QIODevice::Text))
        //错误处理
        return false;
    QVector<QuadTreeNode*> node_list=this->quadTree->getAllIndexNode();
    //写入根节点索引

    QString nodeID="nodeID";
    QString parentID="parentID";
    QString minX="minX";
    QString minY="minY";
    QString maxX="maxX";
    QString maxY="maxY";
    QString S=nodeID+'\t'+parentID+'\t'+minX+'\t'+minY+'\t'+maxX+'\t'+maxY+'\t'+"index_list"+'\n';
    file.write(S.toLatin1());

    QuadTreeNode* node=node_list[0];
    nodeID=QString::number(node->nodeID,10);
    parentID=QString::number(0,10);
    minX=QString("%1").arg(node->minX);
    minY=QString("%1").arg(node->minY);
    maxX=QString("%1").arg(node->maxX);
    maxY=QString("%1").arg(node->maxY);
    QString index_list;
    for(auto outRect:node->indexList)
    {
        index_list=index_list+QString::number(outRect->id,10)+' ';
    }
    S=nodeID+'\t'+parentID+'\t'+minX+'\t'+minY+'\t'+maxX+'\t'+maxY+'\t'+index_list+'\n';
    file.write(S.toLatin1());
    //其余节点写入文件
    for(int i=1;i<node_list.length();++i )
    {
        node=node_list[i];
        nodeID=QString::number(node->nodeID,10);
        parentID=QString::number(node->parent->nodeID,10);
        minX=QString("%1").arg(node->minX);
        minY=QString("%1").arg(node->minY);
        maxX=QString("%1").arg(node->maxX);
        maxY=QString("%1").arg(node->maxY);
        QString index_list;
        for(auto outRect:node->indexList)
        {
            index_list=index_list+QString::number(outRect->id,10)+' ';
        }
        S=nodeID+'\t'+parentID+'\t'+minX+'\t'+minY+'\t'+maxX+'\t'+maxY+'\t'+index_list+'\n';
        file.write(S.toLatin1());
    }
    file.close();
    return true;
}

bool File::makeFileOutRect(QString path)
{
    QString fileName = path+".or";
    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate))
        //错误处理
        return false;
    //流读取文件
    QDataStream stream(&file);
    //windows平台
    stream.setByteOrder(QDataStream::LittleEndian);
    stream<<this->outrectangle_ptr->RectRangeList.length();

    for(auto outRecr:this->outrectangle_ptr->RectRangeList)
    {
        stream<<(int)outRecr->minX<<(int)outRecr->minY<<(int)outRecr->maxX<<(int)outRecr->maxY;
    }
    file.close();
    return true;
}

QList<QPoint> File::getNearbyPoints(int x,int y,int nums)
{
    QList<QPoint> result;
    QVector<int> pro_id_list=this->quadTree->PointResearch(x,y);
    int pro_id_length=pro_id_list.length();

    for(int i=0;i<pro_id_length;++i)
    {
        //i表示该点所在的线的ID号，j表示该点所在的线索引下标
        const QVector<QPoint> line=LineList[pro_id_list[i]];
        const  int pointsCount=line.length();
        for(int j=0;j<pointsCount;++j)
        {
            if(x==line[j].x() && y==line[j].y())
            {
                int now_order=this->LineList[0].length()*i+j;
                if(now_order<nums)
                {
                    for(int l=0;l<now_order+nums+1;++l)
                    {
                        result.append(PointsList[l]);
                    }
                }
                else if(now_order>this->PointsList.length()-1-nums)
                {
                    for(int l=now_order-nums;l<this->PointsList.length()-1;++l)
                    {
                        result.append(PointsList[l]);
                    }
                }
                else
                {
                    for(int l=now_order-nums;l<=now_order+nums;++l)
                    {
                         result.append(PointsList[l]);
                    }
                }
                return result;
            }


        }
    }
}

QList<QPoint> File::getRegionPoints(int minX,int minY,int maxX,int maxY)
{
    QList<QPoint> result;
    QVector<int> result_id=this->quadTree->RegionResearch(minX,minY,maxX,maxY);
    for(auto i:result_id)
    {
        for(auto point:this->LineList[i])
        {
            result.append(point);
        }
    }
    return result;
}

QList<int> File::getAllRange()
{
    QList<int> range;
    range.append(this->quadTree->root->minX);
    range.append(this->quadTree->root->minY);
    range.append(this->quadTree->root->maxX);
    range.append(this->quadTree->root->maxY);
    return range;

}

bool File::readTxtAsData(QString TXTpath,QString DataPath)
{
    reset();
    ReadInit(TXTpath,100);
    makeFileHead(DataPath);
    makeFileIndex(DataPath);
    makeFileOutRect(DataPath);
    return 1;
}

bool File::readFileHead(QString path)
{

    QFile file(path+".data");
    if (!file.open(QIODevice::ReadOnly))
        //错误处理
        return 0;
    //流读取文件
    QDataStream stream(&file);
    //windows平台
    stream.setByteOrder(QDataStream::LittleEndian);
    char c;
    float minX;
    float minY;
    float maxX;
    float maxY;
    char Class;
    int x,y;
    stream>>c>>minX>>minY>>maxX>>maxY>>Class>>this->perLinePointsCount;//读取文件的一行
    qDebug()<<c<<'\t'<<minX<<'\t'<<minY<<'\t'<<maxX<<'\t'<<maxY<<'\t'<<Class<<'\t'<<this->perLinePointsCount;
    //初始化PointsList
    while (!stream.atEnd())
        {
            stream>>x>>y;
            PointsList.append(QPoint(x,y));
        }

    //初始化LineList
    int count=0;
    QVector<QPoint> line;
    int allPointnum=this->PointsList.length();
    for(int i=0;i<allPointnum;++i)
    {
        ++count;
        line.append(PointsList[i]);
        if(count==100)
        {
            this->LineList.append(line);
            line.clear();
            count=0;
        }
    }
    if(count!=100) LineList.append(line);
    return 1;
}


bool File::readFileIndex(QString path)
{
    QMap<int,QuadTreeNode*> node_map;
    QFile file(path+".index");
    if (!file.open(QIODevice::ReadWrite|QIODevice::Text))
        //错误处理
        return false;
    file.readLine();//字段信息

    node_map[0]=nullptr;
    QString index;
    QStringList index_record;
    QStringList outRect_index;
    // 根节点
    QT_TRY
    {
        index=file.readLine();
        index_record=index.split('\t');
        outRect_index=index_record[6].split(' ');
        int nodeID=index_record[0].toInt();
        int parentID=index_record[1].toInt();
        float minX=index_record[2].toFloat();
        float minY=index_record[3].toFloat();
        float maxX=index_record[4].toFloat();
        float maxY=index_record[5].toFloat();
        QuadTreeNode* node=new QuadTreeNode(minX,minY,maxX,maxY,node_map[parentID],nodeID);
        for(int i=0;i<outRect_index.length()-1;++i)
        {
            node->indexList.append(this->outrectangle_ptr->RectRangeList[outRect_index[i].toInt()]);
        }
        node_map[nodeID]=node;
        // 其他节点
        while(!file.atEnd())
        {

            index=file.readLine();
            index_record=index.split('\t');
            outRect_index=index_record[6].split(' ');
            int length=outRect_index.length()-1;
            int nodeID=index_record[0].toInt();
            int parentID=index_record[1].toInt();
            float minX=index_record[2].toFloat();
            float minY=index_record[3].toFloat();
            float maxX=index_record[4].toFloat();
            float maxY=index_record[5].toFloat();
            QuadTreeNode* node=new QuadTreeNode(minX,minY,maxX,maxY,node_map[parentID],nodeID);
            for(int i=0;i<length;++i)
            {
                node->indexList.append(this->outrectangle_ptr->RectRangeList[outRect_index[i].toInt()]);
            }
            node_map[nodeID]=node;
            //判断 该节点属于父节点的哪一个孩子结点
            if(nodeID==4*parentID-2)
            {
                node_map[parentID]->children[0]=node;
            }
            else if(nodeID==4*parentID-1)
            {
                node_map[parentID]->children[1]=node;
            }
            else if(nodeID==4*parentID)
            {
                node_map[parentID]->children[2]=node;
            }
            else if(nodeID==4*parentID+1)
            {
                node_map[parentID]->children[3]=node;
            }

            node_map[nodeID]=node;
        }

        this->quadTree=new QuadTree<RectangleRange>(node_map[1]);


        return 1;
    }
    QT_CATCH(File)
    {
        //错误处理方式
    }

}

bool File::readFileOutRect(QString fileName)
{

    QFile file(fileName+".or");
    if (!file.open(QIODevice::ReadOnly))
        //错误处理
        return false;
    //流读取文件
    QDataStream stream(&file);
    //windows平台
    stream.setByteOrder(QDataStream::LittleEndian);
    int length;
    int minX=0,minY=0,maxX=0,maxY=0;
    stream>>length>>minX;

    QVector<QVector<float>> range_list;
    while(length>0)
    {
        stream>>minX>>minY>>maxX>>maxY;
        QVector<float> range;
        range.append(minX);
        range.append(minY);
        range.append(maxX);
        range.append(maxY);
        --length;
        range_list.append(range);
    }
    this->outrectangle_ptr=new outRectangle(range_list);
    return 1;
}

bool File::readData(QString DataPath)
{
    reset();
    QStringList path=DataPath.split('.');
 QT_TRY{
        readFileOutRect(path[0]);
        readFileIndex(path[0]);
        readFileHead(path[0]);
    }
    QT_CATCH(...)
    {
        //错误处理
    }



}

void File::reset()
{
    if(this->outrectangle_ptr!=nullptr)
    {
        delete this->outrectangle_ptr;
        this->outrectangle_ptr=nullptr;
    }
    if(this->quadTree!=nullptr)
    {
        delete this->quadTree;
        this->quadTree=nullptr;
    }
    QVector<QPoint>().swap(this->PointsList);
    QVector<QVector<QPoint>>().swap(this->LineList);


}
//int main(int argc, char *argv[])
//{
//    File test=File();
////    test.readTxtAsData(":/test_data/high_way.txt","D:/QT/QTcode/OSPractice/test_data/test");

//    test.readData("D:/QT/QTcode/OSPractice/test_data/test.index");
//    qDebug()<<test.getNearbyPoints(7990874,3491825,10);

//    return 1;
//}

