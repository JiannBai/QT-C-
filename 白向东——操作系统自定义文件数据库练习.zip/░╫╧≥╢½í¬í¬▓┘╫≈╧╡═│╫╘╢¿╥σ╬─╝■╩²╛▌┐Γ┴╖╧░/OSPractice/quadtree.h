#ifndef QUADTREE_H
#define QUADTREE_H
#include<QVector>
#include<QQueue>
#include"outrectangle.h"

struct QuadTreeNode
{
    QuadTreeNode* children[4];
    QuadTreeNode* parent;
    QVector<RectangleRange*> indexList;
    float minX,minY,maxX,maxY;
    qint32 nodeID;
    QuadTreeNode():parent(nullptr),minX(0.0),minY(0.0),maxX(0.0),maxY(0.0),nodeID(-1)
    {
        for(auto& node:children)
        {
            node=nullptr;
        }
    }
    QuadTreeNode(float minX,float minY,float maxX,float maxY,QuadTreeNode* parentNode,int nodeID):minX(minX),
        minY(minY),maxX(maxX),maxY(maxY),nodeID(nodeID)
    {
        this->parent=parentNode;
        for(auto& node:children)
        {
            node=nullptr;
        }
    }
    void createChild(int childIndex)
    {
        if(childIndex==1)children[0]=new QuadTreeNode(minX,(minY+maxY)/2,(minX+maxX)/2,maxY,this,4*nodeID-2);
        else if(childIndex==2)children[1]=new QuadTreeNode((minX+maxX)/2,(minY+maxY)/2,maxX,maxY,this,4*nodeID-1);
        else if(childIndex==3)children[2]=new QuadTreeNode(minX,minY,(minX+maxX)/2,(minY+maxY)/2,this,4*nodeID);
        else if(childIndex==4)children[3]=new QuadTreeNode((minX+maxX)/2,minY,maxX,(minY+maxY)/2,this,4*nodeID+1);
    }


};

template<typename RectRangeType>
class QuadTree
{

public:
    QuadTree(const QVector<RectRangeType*> &DataList);//根据外包矩形列表构建树
    QuadTree(QuadTreeNode* root);
    bool Insert(RectRangeType* nodeData);//插入到包含该矩形的最小范围的结点，若没有该节点则创建
    QVector<int> PointResearch(float x,float y);
    QVector<int> RegionResearch(float minX, float minY, float maxX, float maxY);//没找到返回nullptr,找到返回该节点（包含该区域的最小范围）
    bool Delete(QuadTreeNode* node);
    //按层次遍历得到所有的结点,根据这个结点列表建立索引文件
    QVector<QuadTreeNode*> getAllIndexNode();
public:
    QuadTreeNode* root;
private:

    int Compare(QuadTreeNode* node, float minX, float minY, float maxX, float maxY);
    int Compare(QuadTreeNode* node, float X, float Y);
    bool is_in_outRect(float RectMinX,float RectMinY,float RectMaxX,float RectMaxY,float PX,float PY);
    bool is_intersect(float RectMinX,float RectMinY,float RectMaxX,float RectMaxY,
                      float InquireMinX,float InquireMinY,float InquireMaxX,float InquireMaxY);
    void preorder(QuadTreeNode* node,QVector<int>& data,float minX,float minY,float maxX,float maxY);
};














template<typename RectRangeType>
QuadTree<RectRangeType>::QuadTree(QuadTreeNode* root)
{
    this->root=root;
}


template<typename RectRangeType>
QuadTree<RectRangeType>::QuadTree(const QVector<RectRangeType*> &DataList)
{
    float minX=9999999999999999.9;
    float minY=9999999999999999.9;
    float maxX=-9999999999999999.9;
    float maxY=-9999999999999999.9;
    for(auto lineRange:DataList)
    {

            if(lineRange->minX<minX) minX=lineRange->minX;
            if(lineRange->maxX>maxX) maxX=lineRange->minX;
            if(lineRange->minY<minY) minY=lineRange->minY;
            if(lineRange->maxY>maxY) maxY=lineRange->maxY;

    }
    //初始化根节点
    root=new QuadTreeNode(minX-1,minY-1,maxX+1,maxY+1,nullptr,1);
    //插入构建树
    for(auto lineRange:DataList)
    {
        Insert(lineRange);
    }
}


template<typename RectRangeType>
bool QuadTree<RectRangeType>::Insert(RectRangeType* nodeData)
{
    QuadTreeNode* temp=this->root;
    int mark=this->Compare(temp,nodeData->minX,nodeData->minY,nodeData->maxX,nodeData->maxY);
    //Compare返回0表示外包矩形没有完全在该结点的范围
    //1、2、3、4表明外包矩形完全在子节点1、2、3或4的范围中
    int  lastMark=-1;
    while(mark!=0)//当结点不能完全包围该外包矩形时，则将该节点的父节点作为外包矩形的存储结点
    {
        //若该节点为空，则创建该节点
        if(temp->children[mark-1]==nullptr)
        {
           temp->createChild(mark);
        }
        temp=temp->children[mark-1];
        lastMark=mark;
        mark=this->Compare(temp,nodeData->minX,nodeData->minY,nodeData->maxX,nodeData->maxY);
    }
    QuadTreeNode* parent=temp->parent;
    if(parent!=nullptr && mark==0)
    {
//        delete parent->children[lastMark-1];
//        parent->children[lastMark-1]=nullptr;
        parent->indexList.append(nodeData);
        return 1;
    }
    return 0;
}


template<typename RectRangeType>
int QuadTree<RectRangeType>::Compare(QuadTreeNode* node, float minX, float minY, float maxX, float maxY)
{

    //返回1、2、3、4表明外包矩形完全在子节点1、2、3或4的范围中

    //返回0表明外包矩形没有完全在该结点的范围
    if(node->minX<=minX && (node->minY+node->maxY)/2<=minY && (node->minX+node->maxX)/2>=maxX && node->maxY>=maxY)
        return 1;
    else if((node->minX+node->maxX)/2<=minX && (node->minY+node->maxY)/2<=minY && node->maxX>=maxX && node->maxY>=maxY)
        return 2;
    else if(node->minX<=minX && node->minY<=minY && (node->minX+node->maxX)/2>=maxX && (node->minY+node->maxY)/2>=maxY)
        return 3;
    else if((node->minX+node->maxX)/2<=minX && node->minY<=minY && node->maxX>=maxX && (node->minY+node->maxY)/2>=maxY)
        return 4;
      //5表明完全在该结点区域内
//    else if(node->minX<=minX && node->minY>=minY && node->maxX<=maxX && node->maxY<=maxY)
//        return 5;
    else return 0;

}

template<typename RectRangeType>
int QuadTree<RectRangeType>::Compare(QuadTreeNode* node, float X, float Y)
{
    //需要检查
    //返回0表明外包矩形没有完全在该结点的范围
    if(node->minX>X || node->minY>Y || node->maxX<X || node->maxY<Y) return 0;
    //1、2、3、4表明外包矩形完全在子节点1、2、3或4的范围中
    else
    {
        if(node->minX<=X && (node->minY+node->maxY)/2<=Y && (node->minX+node->maxX)/2>=X && node->maxY>=Y)
            return 1;
        else if((node->minX+node->maxX)/2<=X && (node->minY+node->maxY)/2<=Y && node->maxX>=X && node->maxY>=Y)
            return 2;
        else if(node->minX<=X && node->minY<=Y && (node->minX+node->maxX)/2>=X && (node->minY+node->maxY)/2>=Y)
            return 3;
        else if((node->minX+node->maxX)/2<=X && node->minY<=Y && node->maxX>=X && (node->minY+node->maxY)/2>=Y)
            return 4;
    }

}
template<typename RectRangeType>
bool QuadTree<RectRangeType>::is_in_outRect(float RectMinX,float RectMinY,float RectMaxX,float RectMaxY,float PX,float PY)
{
    return (PX>=RectMinX && PX<RectMaxX && PY>=RectMinY && PY<=PX<RectMaxY);
}

template<typename RectRangeType>
bool QuadTree<RectRangeType>::is_intersect(float RectMinX,float RectMinY,float RectMaxX,float RectMaxY,
                  float InquireMinX,float InquireMinY,float InquireMaxX,float InquireMaxY)
{
    bool X_inter= (RectMaxX>=InquireMinX) && (InquireMaxX>=RectMinX);
    bool Y_inter=(RectMaxY>=InquireMinY) && (InquireMaxY>=RectMinY);
    return (X_inter && Y_inter);
}

template<typename RectRangeType>
void QuadTree<RectRangeType>::preorder(QuadTreeNode* node,QVector<int>& data,float minX,float minY,float maxX,float maxY)
{
    if(node!=nullptr)
    {
        for(auto outRect:node->indexList)
        {
            if(this->is_intersect(outRect->minX,outRect->minY,outRect->maxX,outRect->maxY,minX,minY,maxX,maxY))
            {
                data.append(outRect->id);
            }
        }
        preorder(node->children[0],data,minX,minY,maxX,maxY);
        preorder(node->children[1],data,minX,minY,maxX,maxY);
        preorder(node->children[2],data,minX,minY,maxX,maxY);
        preorder(node->children[3],data,minX,minY,maxX,maxY);
    }
}

template<typename RectRangeType>
QVector<int> QuadTree<RectRangeType>::PointResearch(float x,float y)
{
    QuadTreeNode* temp=this->root;
    QVector<QuadTreeNode*> result_nodes;
    QVector<int> pro_id;
    int mark=Compare(temp,x,y);
    int mark2=-1;
    if(mark!=0)//若点在范围中必定返回一个结点
    {
        //当该结点的包围该点的子节点不存在时，返回当前节点（说明当前节点为包围该点所在线的外包矩形的最小范围）
        while(temp->children[mark-1]!=nullptr)
        {
            result_nodes.append(temp);
            mark2=this->Compare(temp->children[mark-1],x,y);
            temp=temp->children[mark-1];
            mark=mark2;
        }
        int pro_node_length=result_nodes.length();
        for(int i=pro_node_length-1;i>=0;--i)
        {
            for(RectangleRange* outRect:result_nodes[i]->indexList)
            {
                if(this->is_in_outRect(outRect->minX,outRect->minY,outRect->maxX,
                                       outRect->maxY,x,y))//如果该点与该节点中的某个外包矩形相交,则判断
                {
                    pro_id.append(outRect->id);

                }
            }
        }

        return pro_id;
    }
    else//若点没在范围中，返回-1
    {
        return pro_id;
    }
}



template<typename RectRangeType>
QVector<int> QuadTree<RectRangeType>::RegionResearch( float minX, float minY, float maxX, float maxY)
{
    QVector<int> result_id;
    QuadTreeNode* temp=this->root;
    //返回所有有交集的结点
    int mark=this->Compare(temp,minX,minY,maxX,maxY);
    int last_mark=-1;
    while(mark!=0)//当结点不能完全包围该外包矩形时，
    {
        if(temp->children[mark-1]!=nullptr)
        {
            last_mark=mark;
            mark=this->Compare(temp,minX,minY,maxX,maxY);
            temp=temp->children[last_mark-1];
        }

    }

    if(last_mark!=-1)//从根节点查找
    {
        this->preorder(temp->parent,result_id,minX,minY,maxX,maxY);
    }
    else
    {
         this->preorder(temp,result_id,minX,minY,maxX,maxY);
    }
    return result_id;
}


template<typename RectRangeType>
QVector<QuadTreeNode*> QuadTree<RectRangeType>::getAllIndexNode()
{
    QVector<QuadTreeNode*> result;
    QQueue<QuadTreeNode*> node_queue;
    QuadTreeNode* node=nullptr;
    node_queue.enqueue(root);
    while(!node_queue.empty())
    {
        node=node_queue.head();
        node_queue.dequeue();
        if(node!=nullptr)//子节点入栈
        {
            result.append(node);
            for(auto child:node->children)
            {
                node_queue.enqueue(child);
            }
        }
    }
    return result;
}



#endif
